# Establecer directorio de trabajo
setwd("/tu/ruta/")

#Instalar y cargar paquetes
install.packages("ggplot2")

library(ggplot2)

# Importar tabla de datos
datos <- read.csv("alturas_encinas.csv", sep = ";", dec = ",")

# Crear el histograma
ggplot(datos, aes(x = Altura)) +
  geom_histogram(binwidth = 1, fill = "blue", color = "black") +
  ggtitle("Distribución de Alturas de la Especie") +
  xlab("Altura (metros)") +
  ylab("Frecuencia")


