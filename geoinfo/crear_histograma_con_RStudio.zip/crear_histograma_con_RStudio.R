# Establecer directorio de trabajo
setwd("tu ruta aquí")

# Importar tabla de datos
datos <- read.csv("alturas_encinas.csv", header = TRUE, sep = ";", dec = ",")

# visualizamos la tabla. Esto es útil sobre todo para los que no usan RStudio
View(datos)

#Instalar y cargar paquetes
install.packages("ggplot2")
library(ggplot2)

# Crear el histograma
ggplot(datos, aes(x = Altura)) +
  geom_histogram(binwidth = 1, fill = "blue", color = "black") +
  ggtitle("Distribución de Alturas de la Especie") +
  xlab("Altura (metros)") +
  ylab("Frecuencia")


